const galleryImages = document.querySelectorAll(".gallery img");

galleryImages.forEach((image) => {
  image.addEventListener("click", () => {
    image.classList.toggle("enlarged");
  });
});
const photos = document.querySelectorAll(".about-photo");
const previousButton = document.getElementById("previous-photo");
const nextButton = document.getElementById("next-photo");

let currentPhoto = 0;

function showPhoto(index) {
  if (photos.length === 0) return;

  currentPhoto = (index + photos.length) % photos.length;

  photos.forEach((photo, i) => {
    photo.classList.toggle("active", i === currentPhoto);
  });
}

previousButton?.addEventListener("click", () => {
  showPhoto(currentPhoto - 1);
});

nextButton?.addEventListener("click", () => {
  showPhoto(currentPhoto + 1);
});

// Clicking the displayed photo moves to the next one.
photos.forEach((photo) => {
  photo.addEventListener("click", () => {
    showPhoto(currentPhoto + 1);
  });
});

showPhoto(currentPhoto);
const contactForm = document.getElementById("contact-form");

if (contactForm) {
  contactForm.addEventListener("submit", (event) => {
    if (!contactForm.checkValidity()) {
      event.preventDefault();
      contactForm.reportValidity();
      return;
    }

    alert("Thank you! Your form is ready to be submitted.");
  });
}